echo -e "Starting to update test\n"

cd
# Go to home and setup git
git config --global user.email "travis@travis-ci.org"
git config --global user.name "Travis"

# Using token clone master branch
git clone --branch=master https://73c05362840983520a9d923270d94df6920d8569@github.com/CatBlock/catblock.git

# Add, commit and push files
cd catblock/

git add -f .
git commit -m "Travis build pushed to test branch"
git push -fq origin test

echo -e "Done updating builds on GitHub."